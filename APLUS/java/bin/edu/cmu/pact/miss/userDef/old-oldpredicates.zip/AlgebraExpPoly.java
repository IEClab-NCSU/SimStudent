/**
 * Describe class AlgebraExpPoly here.
 *
 *
 * Created: Mon Aug 01 18:37:29 2005
 *
 * @author <a href="mailto:Noboru.Matsuda@cs.cmu.edu">Noboru Matsuda</a>
 * @version 1.0
 */

package edu.cmu.pact.miss.userDef;

import java.util.*;
import edu.cmu.old_pact.dormin.*;

public class AlgebraExpPoly extends AlgebraExp {

    public boolean isPolynomial() { return true; }
    public boolean isTerm() {
	return getOp().equals( "*" ) ||
	    getOp().equals( "/" );
    }
    public boolean isValidPolynomial() {
	return getFirstTerm() != null && getSecondTerm() != null;
    }

    public boolean isZero() { return false; }

    /**
     * Creates a new <code>AlgebraExpPoly</code> instance.
     *
     */
    public AlgebraExpPoly() {

    }

    /**
     * Creates a new <code>AlgebraExp</code> instance.
     *
     */
    public AlgebraExpPoly( String op, AlgebraExp firstT, AlgebraExp secondT ) {

	setOp( op );
	setFirstTerm( firstT );
	setSecondTerm( secondT );
    }

    // -
    // - Methods - - - - - - - - - - - - - - - - - - - - - - - - -
    // -

    String getVarName() {

	String exp = getFirstTerm().getVarName();
	if ( exp == null ) {
	    exp = getSecondTerm().getVarName();
	}

	return exp;
    }

    String getCoefficient() {

	String coefficient = null;

	if ( getFirstTerm().isTerm() && getSecondTerm().isTerm() &&
	     ( getOp().equals( "*" ) || getOp().equals( "/" ) ) ) {

	    String c1 = getFirstTerm().getCoefficient();

	    if ( c1 != null ) {
		String c2 = getSecondTerm().isConstTerm() ?
		    getSecondTerm().getExp() : 
		    getSecondTerm().getCoefficient();
		
		coefficient = c1 + getOp() + c2;
	    }
	}
	return coefficient;
    }

    // - 
    // - Simplify expressions - * - * - * - * - * - * - * - * - * - 
    // - 

    public AlgebraExp evalArithmetic() {

	// System.out.print(this + ".evalArithmetic() ... ");
	AlgebraExp evalArithmetic = null;

	if ( getSecondTerm().isTerm() ) {

	    evalArithmetic = doArithmetic();

	} else {

	    AlgebraExp normalSecond = getSecondTerm().evalArithmetic();
	    evalArithmetic = normalSecond.isZero() ?
		getFirstTerm().evalArithmetic() :
		doArithmetic( getOp(), getFirstTerm().evalArithmetic(), normalSecond ) ;
	}

	// System.out.println(evalArithmetic);
	// System.out.println(this + ".evalArithmetic() -> " + evalArithmetic);
	return evalArithmetic;
    }

    AlgebraExp doArithmetic() {
	return doArithmetic( getOp(), getFirstTerm().evalArithmetic(), getSecondTerm().evalArithmetic() );
    }

    // Assume that the expression "t1" is a term and the expression
    // "t2" is a normal term (i.e., the terms in the expression is
    // ordered), place t1 in an appropriate position in t2 with a
    // necessary calculation.
    // 
    AlgebraExp doArithmetic( String op, AlgebraExp t1, AlgebraExp t2 ) {

	AlgebraExp doArithmetic = null;

	if ( op.equals( "+" ) ) {
	    
	    // System.out.println("doArithmetic(" + t1 + "," + t2 + ")...");
	    
	    if ( t2.isZero() ) {

		doArithmetic = t1;

	    } else if ( t1.isTerm() && t2.isTerm() ) {
		
		// System.out.println("t2.isTerm()");
		doArithmetic = evalArithmeticAdd( t1, t2 );

	    } else if ( !t1.isTerm() && t2.isTerm() ) {
		
		doArithmetic = doArithmetic( op, t2, t1 );
		
	    } else if ( !t1.isTerm() && !t2.isTerm() ) {
		
		// System.out.println("!t1.isTerm() : " + t1);
		/*
		doArithmetic = t1.comesBefore(t2) ?
		    new AlgebraExpPoly( op, t1, t2 ) :
		    new AlgebraExpPoly( op, t2, t1 ) ;
		*/
		doArithmetic = 
		    doArithmetic(op, t1.getSecondTerm(), doArithmetic(op, t1.getFirstTerm(), t2));

	    } else {

		AlgebraExp sameTerm = t2.lookupSameTypeTerm( "+", t1 );
		// System.out.println( "doArithmetic: sameTerm = " + sameTerm );
		if ( sameTerm != null ) {
		    
		    AlgebraExp newTerm = evalArithmeticAdd( t1, sameTerm );
		    // System.out.println("newTerm = " + newTerm);
		    doArithmetic = t2.replaceTerm( sameTerm, newTerm );

		} else {
		    
		    doArithmetic = new AlgebraExpPoly( op, t1, t2 );
		}
	    }
	    
	} else if ( op.equals( "*" ) ) {
	    
	    doArithmetic = evalArithmeticMult( t1, t2 );
	    
	} else if ( op.equals( "/" ) ) {
	    
	    doArithmetic = evalArithmeticDiv( t1, t2 );

	} else {
	
	    String msg = "Invalid expression: " + toString();
	    RuntimeException e = new RuntimeException( msg );
	    e.printStackTrace();
	}

	// doArithmetic migth eventually got a polynomial that has
	// null as its term
	if ( doArithmetic != null &&
	     doArithmetic.isPolynomial() &&
	     !doArithmetic.isValidPolynomial() ) {
	    doArithmetic = null;
	}

	return doArithmetic;
    }

    public AlgebraExp evalArithmetic_obsolete() {

	AlgebraExp t1 = getFirstTerm();
	AlgebraExp t2 = getSecondTerm();

	if ( getOp().equals( "+" ) ) {
	    
	    return evalArithmeticAdd( t1, t2 );
	    
	} else if ( getOp().equals( "*" ) ) {
	    
	    // System.out.println("AlgebraExpPoly.evalArithmetic() -> Mult");
	    return evalArithmeticMult( t1, t2 );
	    
	} else if ( getOp().equals( "/" ) ) {
	    
	    return evalArithmeticDiv( t1, t2 );
	}

	String msg = "Invalid expression: " + toString();
	RuntimeException e = new RuntimeException( msg );
	e.printStackTrace();

	return null;
    }

    public AlgebraExp addTerm( AlgebraExp term ) {

	trace.out("eqfp", "addTerm(" + term + ") called upon " + this);
	return null;
    }

    public AlgebraExp divTerm( AlgebraExp term ) {

	// System.out.println(this + ".AlgebraExpPoly.divTerm(" + term + ")");
	AlgebraExp divTerm = null;
	AlgebraExp inverseTerm = null;

	if ( term.isZero() ) {

	    return null;

	} else if ( this.equals(term) ) {

	    return new AlgebraExpTerm( "1" );

	} else if ( term.isFraction() && !term.getNumerator().isZero() ) {

	    inverseTerm = new AlgebraExpPoly( "/",
					      term.getDenominator(),
					      term.getNumerator() );
	    divTerm = multTerm( inverseTerm );
	    
	} else if ( isFraction() ) {

	    inverseTerm = getNumerator().divTerm( term );

	    // System.out.println("inverseTerm = " + inverseTerm);

	    if ( inverseTerm != null ) {

		if ( inverseTerm.isFraction() ) {
		    
		    AlgebraExp denominator =
			getDenominator().multTerm( inverseTerm.getDenominator() );
		    
		    if ( denominator != null && !denominator.isZero() ) {
			divTerm =
			    new AlgebraExpPoly( "/",
						inverseTerm.getNumerator(),
						denominator );
		    }
		    
		} else {
		    
		    divTerm =
			new AlgebraExpPoly("/", inverseTerm, getDenominator());
		}
	    }

	} else {

	    divTerm = new AlgebraExpPoly( "/", this, term );

	}

	// System.out.println(" ==> " + divTerm);
	return divTerm;
    }

    public AlgebraExp multTerm( AlgebraExp term ) {

	AlgebraExp multTerm = null;

	if ( isFraction() ) {

	    // System.out.println(this + ".multTerm(" + term + ")");

	    AlgebraExp multiplier = term.divTerm( getDenominator() );
	    // System.out.println("multiplier = " + multiplier);

	    if ( multiplier != null ) {

		if ( multiplier.isFraction() ) {

		    AlgebraExp numerator =
			getNumerator().multTerm( multiplier.getNumerator() );
		    
		    if ( numerator != null ) 
			multTerm =
			    new AlgebraExpPoly( "/",
						numerator,
						multiplier.getDenominator() );
		} else {
		    
		    multTerm = getNumerator().multTerm( multiplier );
		}
	    }

	} else if ( isAddition() ) {

	    AlgebraExp exp1 = getFirstTerm().multTerm( term );
	    AlgebraExp exp2 = getSecondTerm().multTerm( term );
	    if (exp1 != null && exp2 != null) 
		multTerm = new AlgebraExpPoly( getOp(), exp1, exp2 );

	} else { // isMultiplication()

	    AlgebraExp exp = getSecondTerm().multTerm( term );
	    if ( exp != null) 
		multTerm = new AlgebraExpPoly( getOp(), getFirstTerm(), exp );
	}
	return multTerm;
    }

    // -
    // - Look up for a particular term - * - * - * - * - * - * - * - * 
    // -

    


    // -
    // - Predicates - * - * - * - * - * - * - * - * - * - * - * - * -
    // -

    boolean isConstTerm() {
	return getFirstTerm().isConstTerm() &&
	    getSecondTerm().isConstTerm();
    }

    boolean isVarTerm() {
	return getFirstTerm().isVarTerm() || getSecondTerm().isVarTerm();
    }

    boolean equals( AlgebraExp term ) {

	return term.isPolynomial() &&
	    getOp().equals( term.getOp() ) &&
	    getFirstTerm().equals( term.getFirstTerm() ) &&
	    getSecondTerm().equals( term.getSecondTerm() );
    }

    // -
    // - Printing - * - * - * - * - * - * - * - * - * - * - * - * - *
    // -

    public String parseTree() {
	String parseTree =
	    "(" +
	    getOp() + " " +
	    getFirstTerm().parseTree() + " " +
	    getSecondTerm().parseTree() +
	    ")";
	return parseTree;
    }

    /**
     * Convert to plane string
     *
     * @return a <code>String</code> value
     */
    public String toString() {

	String term1 = getFirstTerm().toString();
	String term2 = getSecondTerm().toString();

	if ( getFirstTerm().isAddition() ) {
	    term1 = "(" + term1 + ")";
	}
	if  ( secondTermNeedParenthesis() ) {
	    term2 = "(" + term2 + ")"; 
	}

	String op = ( getOp().equals( "+" ) && term2.charAt(0) == '-' ) ?
	    "" :
	    getOp();
	return term1 + op + term2;
    }

    private boolean secondTermNeedParenthesis() {

	boolean answer = false;

	if ( !getOp().equals("+") && getSecondTerm().isPolynomial() ) {

	    answer = true;

	} else if ( getOp().equals("/") ) {

	    if ( getSecondTerm().isVarTerm() &&
		 !getSecondTerm().getCoefficient().equals("1") ) {

		answer = true;

	    } else if ( getSecondTerm().isConstTerm() &&
			getSecondTerm().toString().charAt(0) == '-' ) {

		answer = true;
	    }
	}
	return answer;
    }

}
