/**
 * Describe class CanBeSimplified here.
 *
 *
 * Created: Thu Nov 17 23:23:40 2005
 *
 * @author <a href="mailto:Noboru.Matsuda@cs.cmu.edu">Noboru Matsuda</a>
 * @version 1.0
 */
package edu.cmu.pact.miss.userDef;

import java.util.*;

public class CanBeSimplified extends EqFeaturePredicate {

    /**
     * Creates a new <code>CanBeSimplified</code> instance.
     *
     */
    public CanBeSimplified() {
	setName( "can-be-simplified" );
	setArity( 1 );
    }

    public String apply( Vector /* String */ args ) {

	String arg = (String)args.get(0);
	// System.out.println("CanBeSimplified(" + arg + ") = " + canBeSimplified(arg));
	return canBeSimplified( arg );
    }
}
