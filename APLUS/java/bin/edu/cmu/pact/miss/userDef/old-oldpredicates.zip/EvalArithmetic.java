/**
 * Describe class EvalArithmetic here.
 *
 *
 * Created: Tue Mar 15 17:29:18 2005
 *
 * @author <a href="mailto:mazda@cs.cmu.edu">Noboru Matsuda</a>
 * @version 1.0
 */

package edu.cmu.pact.miss.userDef;

import java.util.*;
import edu.cmu.pact.miss.*;

public class EvalArithmetic extends EqFeaturePredicate {

    /**
     * Creates a new <code>EvalArithmetic</code> instance.
     *
     */
    public EvalArithmetic() {

	setName( "eval-arithmetic" );
	setArity( 1 );
    }

    public String apply( Vector /* String */ args ) {
	String arg = (String)args.get(0);
	// System.out.println("EvalArithetic(" + arg + ") = " + evalArithmetic(arg));
	return evalArithmetic( arg );
    }
}
