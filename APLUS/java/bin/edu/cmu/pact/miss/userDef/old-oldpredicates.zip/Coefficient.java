/**
 * f:/Project/CTAT/ML/ISS/miss/userDef/Coefficient.java
 *
 *
 * Created: Mon Feb 28 17:32:41 2005
 *
 * @author <a href="mailto:mazda@cs.cmu.edu">Noboru Matsuda</a>
 * @version 1.0
 **/

package edu.cmu.pact.miss.userDef;

import java.util.*;
import edu.cmu.pact.miss.*;

public class Coefficient extends EqFeaturePredicate {

    /**
     * Creates a new <code>Coefficient</code> instance.
     *
     */
    public Coefficient() {

	setName( "coefficient" );
	setArity( 1 );
    }

    public String apply( Vector /* of String */ args ) {
	return coefficient( (String)args.get(0) );
    }

}

//
// end of f:/Project/CTAT/ML/ISS/miss/userDef/Coefficient.java
// 
