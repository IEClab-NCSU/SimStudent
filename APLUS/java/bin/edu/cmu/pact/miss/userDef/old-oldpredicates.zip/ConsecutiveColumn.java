/**
 * Describe class ConsecutiveColumn here.
 *
 *
 * Created: Fri Jun 03 22:27:01 2005
 *
 * @author <a href="mailto:Noboru.Matsuda@cs.cmu.edu">Noboru Matsuda</a>
 * @version 1.0
 */

package edu.cmu.pact.miss.userDef;

import java.util.*;

public class ConsecutiveColumn extends EqFeaturePredicate {

    /**
     * Creates a new <code>ConsecutiveColumn</code> instance.
     *
     */
    public ConsecutiveColumn() {
	setName( "consecutive-column" );
	setArity( 2 );
    }

    public String apply( Vector /* String */ args ) {
	return consecutiveColumn( (String)args.get(0), (String)args.get(1) );
    }
}
