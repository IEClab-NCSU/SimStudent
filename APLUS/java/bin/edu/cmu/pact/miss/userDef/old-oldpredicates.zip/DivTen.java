/**
 * Describe class DivTen here.
 *
 *
 * Created: Tue Sep 13 15:34:06 2005
 *
 * @author <a href="mailto:Noboru.Matsuda@cs.cmu.edu">Noboru Matsuda</a>
 * @version 1.0
 */

package edu.cmu.pact.miss.userDef;

import java.util.*;
import edu.cmu.pact.miss.*;

public class DivTen extends EqFeaturePredicate {

    /**
     * Creates a new <code>DivTen</code> instance.
     *
     */
    public DivTen() {
	setName( "div-ten" );
	setArity( 1 );
    }

    public String apply( Vector /* String */ args ) {
	return divTen( (String)args.get(0) );
    }
}
