/**
 * Describe class SameRow here.
 *
 *
 * Created: Fri Jun 03 22:14:43 2005
 *
 * @author <a href="mailto:Noboru.Matsuda@cs.cmu.edu">Noboru Matsuda</a>
 * @version 1.0
 */

package edu.cmu.pact.miss.userDef;

import java.util.*;

public class SameRow extends EqFeaturePredicate {

    /**
     * Creates a new <code>SameRow</code> instance.
     *
     */
    public SameRow() {
	setName( "same-row" );
	setArity( 2 );
    }

    public String apply( Vector /* String */ args ) {
	return sameRow( (String)args.get(0), (String)args.get(1) );
    }

}
