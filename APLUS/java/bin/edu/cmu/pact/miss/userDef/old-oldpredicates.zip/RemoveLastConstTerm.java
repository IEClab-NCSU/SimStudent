/**
 * Describe class RemoveLastConstTerm here.
 *
 *
 * Created: Sat Apr 09 22:06:12 2005
 *
 * @author <a href="mailto:mazda@cs.cmu.edu">Noboru Matsuda</a>
 * @version 1.0
 */

package edu.cmu.pact.miss.userDef;

import java.util.*;

public class RemoveLastConstTerm extends EqFeaturePredicate {

    /**
     * Creates a new <code>RemoveLastConstTerm</code> instance.
     *
     */
    public RemoveLastConstTerm() {

	setName( "remove-last-const-term" );
	setArity( 1 );
    }

    public String apply( Vector /* String */ args ) {
	return removeLastConstTerm( (String)args.get(0) );
    }
}
