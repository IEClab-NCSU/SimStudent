/**
 * Describe class Homogeneous here.
 *
 *
 * Created: Sat Apr 09 17:09:42 2005
 *
 * @author <a href="mailto:mazda@cs.cmu.edu">Noboru Matsuda</a>
 * @version 1.0
 */

package edu.cmu.pact.miss.userDef;

import java.util.*; 
import edu.cmu.pact.miss.*;

public class Homogeneous extends EqFeaturePredicate {

    /**
     * Creates a new <code>Homogeneous</code> instance.
     *
     */
    public Homogeneous() {

	setName( "homoneneous" );
	setArity( 1 );
    }

    public String apply( Vector /* String */ args ) {
	return homogeneous( (String)args.get(0) );
    }
}
