/**
 * Describe class Numerator here.
 *
 *
 * Created: Sat Aug 06 02:03:32 2005
 *
 * @author <a href="mailto:Noboru.Matsuda@cs.cmu.edu">Noboru Matsuda</a>
 * @version 1.0
 */

package edu.cmu.pact.miss.userDef;

import java.util.*;

public class Numerator extends EqFeaturePredicate {

    /**
     * Creates a new <code>Numerator</code> instance.
     *
     */
    public Numerator() {

	setName( "numerator" );
	setArity( 1 );
    }

    public String apply( Vector /* String */ args ) {
	return numerator( (String)args.get(0) );
    }
}
